const express = require('express');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();

const app = express();

// 連接 SQLite 資料庫
const dbPath = path.join(__dirname, 'resource', 'sqlite.db');
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('資料庫連線失敗:', err.message);
    } else {
        console.log('成功連接資料庫:', dbPath);
    }
});

// 中介層
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

// 查詢 API：只根據日期搜尋
app.get('/api/pigs', (req, res) => {
    const keyword = req.query.q || '';
    const sql = `
    SELECT * FROM livestock_transactions
    WHERE trade_date LIKE ?
    ORDER BY trade_date DESC
  `;
    db.all(sql, [`%${keyword}%`], (err, rows) => {
        if (err) return res.status(500).json({ error: '查詢失敗' });
        res.json(rows);
    });
});

// 首頁載入 HTML
const fs = require('fs');
app.get('/', (req, res) => {
    fs.readFile(path.join(__dirname, 'public', 'index.html'), 'utf8', (err, html) => {
        if (err) {
            res.status(500).send('載入頁面失敗');
        } else {
            res.send(html);
        }
    });
});

// ... 所有其他程式碼 ...

module.exports = app;

